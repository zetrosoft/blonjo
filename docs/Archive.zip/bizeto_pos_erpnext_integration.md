# Bizeto POS ERPNext Plug-and-Play Integration

Dokumen ini menjelaskan rancangan integrasi Bizeto POS dengan ERPNext dalam mode **plug-and-play**:

- tanpa custom app di ERPNext
- tanpa custom doctype di ERPNext
- tanpa server script khusus di ERPNext
- tanpa mengubah inti ERPNext

Semua adaptasi dilakukan dari sisi POS frontend dan adapter integrasi.

## Tujuan Integrasi

1. POS bisa login ke ERPNext standar.
2. POS bisa membaca master data ERPNext.
3. POS bisa membuat transaksi penjualan.
4. POS bisa menangani offline queue.
5. POS tetap jalan meski koneksi putus sementara.

## Prinsip Plug-and-Play

- ERPNext diperlakukan sebagai sistem sumber data dan transaksi standar.
- Bizeto POS hanya memakai API resmi ERPNext.
- Semua mapping bersifat konfigurasi, bukan custom kode di ERPNext.
- Jika ada metadata Bizeto yang tidak tersedia di ERPNext standar, metadata itu disimpan di POS atau di backend bridge milik Bizeto, bukan di ERPNext.

## Metode Koneksi

### Auth

Gunakan autentikasi standar Frappe/ERPNext:

- API Key
- API Secret

Alternatif setup awal:

- login session biasa jika diperlukan untuk wizard

### Base URL

POS menyimpan:

- URL ERPNext
- company
- outlet / warehouse
- price list
- POS profile
- mode of payment default

## Data Yang Dibaca Dari ERPNext

### Master Data

- Item
- Item Group
- Item Price
- UOM
- Customer
- Address
- Warehouse
- Price List
- Tax Template
- Mode of Payment
- POS Profile

### Data Operasional

- stok item
- harga per price list
- pelanggan aktif
- invoice history
- payment status

## Data Yang Dikirim Ke ERPNext

- Sales Invoice atau POS Invoice
- Payment Entry
- attachment bila ada gambar atau bukti
- referensi transaksi

## Mapping Konsep

| Bizeto POS | ERPNext Standar |
| --- | --- |
| Outlet | Company / Warehouse / POS Profile |
| Produk | Item |
| Kategori | Item Group |
| Harga jual | Item Price / Pricing Rule |
| Pelanggan | Customer |
| Nota | Sales Invoice / POS Invoice |
| Bayar tunai / QR / transfer | Payment Entry / Mode of Payment |
| Stok | Bin / stock report |
| Lampiran kamera | File attachment |

## Arsitektur Integrasi

```mermaid
graph TD
    A[Bizeto POS Frontend] --> B[ERPNext REST API]
    A --> C[Local Offline Queue]
    C --> A
    B --> D[Standard ERPNext Docs]
    D --> E[Item]
    D --> F[Customer]
    D --> G[Sales Invoice]
    D --> H[Payment Entry]
    D --> I[Warehouse / Stock]
```

## Flow Integrasi

### 1. Setup Awal

Kasir atau admin memasukkan:

- ERPNext URL
- API key
- API secret
- company
- warehouse
- price list
- mode of payment

### 2. Sync Master Data

POS menarik data standar dari ERPNext:

- item
- harga
- stok
- customer
- payment mode

### 3. Transaksi

Saat checkout:

- POS membuat draft transaksi lokal
- POS mengirim payload ke ERPNext
- ERPNext mengembalikan nomor dokumen
- POS menandai transaksi sebagai sukses

### 4. Offline Fallback

Jika ERPNext tidak bisa diakses:

- transaksi tetap disimpan lokal
- antrian sync menunggu koneksi pulih
- saat koneksi kembali, POS push ulang secara berurutan

## Strategi Tanpa Custom ERPNext

Yang tidak dilakukan:

- tidak membuat custom app ERPNext
- tidak membuat custom doctype
- tidak membuat server script ERPNext
- tidak mengubah core module ERPNext

Yang dilakukan:

- pakai REST API standar
- pakai dokumen standar ERPNext
- pakai konfigurasi di POS
- pakai adapter lokal untuk mapping field

## Idempotency

Karena tidak ada custom field di ERPNext, idempotency dikelola dari sisi Bizeto POS:

- setiap transaksi punya UUID lokal
- UUID dipakai untuk tracking queue di POS
- saat retry, POS memeriksa status request sebelumnya
- jika perlu, POS mencocokkan hasil berdasarkan nomor dokumen ERPNext yang sudah diterima

Intinya:

- sumber kebenaran retry ada di POS
- ERPNext hanya menerima transaksi standar

## Print dan Nota

Ada dua pendekatan:

1. **Local print**
   - nota dicetak dari POS
   - cocok untuk thermal printer kasir

2. **ERPNext print format**
   - POS mengambil data invoice dari ERPNext
   - lalu menampilkan atau mencetak dengan template standar

Untuk plug-and-play, local print adalah jalur utama karena tidak bergantung pada custom print format ERPNext.

## Penanganan Lampiran Kamera

Jika ada capture image atau voice note yang berubah jadi lampiran:

- file diunggah ke ERPNext sebagai attachment standar
- metadata visual tetap disimpan di POS bila perlu

## Mode Integrasi

### Online Direct

- POS terhubung langsung ke ERPNext
- cocok untuk outlet yang koneksinya stabil

### Offline Queue

- POS menyimpan transaksi lokal lebih dulu
- sync menyusul saat online

### Hybrid

- master data dibaca online
- transaksi bisa tetap jalan offline

## Batasan Desain

- Bizeto POS tidak boleh bergantung pada custom ERPNext logic.
- Semua aturan bisnis tambahan harus bisa diproses di POS atau adapter sendiri.
- Jika ERPNext punya variasi konfigurasi antar company, itu dipilih lewat wizard POS.

## Rekomendasi Implementasi

1. Buat connector REST standar.
2. Buat mapping layer data.
3. Buat sync queue lokal.
4. Buat transaction writer.
5. Buat fallback print lokal.
6. Baru tambah sinkronisasi lampiran dan konflik data.

## Output Yang Diharapkan

- POS bisa terhubung ke ERPNext standar tanpa custom di ERPNext
- master data bisa dipakai langsung
- transaksi bisa ditulis sebagai dokumen ERPNext standar
- offline tetap aman
- integrasi mudah dipasang ulang di banyak tenant

