# Bizeto POS Theme System

Dokumen ini menjelaskan rancangan agar seluruh UI/UX Bizeto POS tetap memakai **satu codebase yang sama**, tetapi bisa tampil sebagai theme POS berdasarkan tipe usaha.

## Tujuan

- Satu source code untuk retail, F&B, dan bengkel.
- Satu flow state untuk transaksi, pembayaran, voice, dan vision.
- Tema hanya mengubah tampilan, densitas, dan prioritas komponen.
- Portrait, landscape, minimal, dan premium luxury adalah variasi render dari shell yang sama.

## Prinsip Arsitektur

1. **Single App Shell**
   - Semua mode memakai struktur komponen yang sama.
   - Tidak ada jalur code berbeda untuk retail vs F&B vs bengkel.

2. **Theme Pack**
   - Theme pack hanya menyimpan tokens, layout weights, icon emphasis, dan copy domain.
   - Theme pack dipilih berdasarkan tipe usaha.

3. **Slot-Based Layout**
   - App shell menyediakan slot standar.
   - Isi slot boleh berbeda, tetapi slot-nya tetap sama.

4. **Responsive Reflow**
   - Landscape dan portrait tidak dibuat sebagai aplikasi berbeda.
   - Keduanya adalah reflow dari komponen yang sama.

5. **Domain Modules**
   - Retail, F&B, dan bengkel punya modul tambahan masing-masing.
   - Modul tambahan ditempel ke shell, bukan mengganti shell.

## Baseline Coding

Basis implementasi yang paling aman adalah:

- **Core Shell generik**
- dengan referensi density dari **Retail Core Landscape**

Kenapa retail core dipakai sebagai referensi awal:

- paling netral untuk POS umum
- paling dekat ke scan-cart-pay flow
- mudah direflow ke F&B dan bengkel
- cocok untuk tablet landscape maupun portrait

Jadi yang dijadikan dasar coding bukan satu gambar final, melainkan:

- shell komponen inti
- contract antar slot
- token tema
- state flow yang sama

## Komponen Inti

### Slot Wajib

- `AppShell`
- `HeaderStatus`
- `BusinessSwitcher`
- `InputDock`
- `CandidateStrip`
- `WorkSurface`
- `PaymentSummary`
- `ActionFooter`
- `OverlayDrawer`

### Komponen Bersama

- search / barcode input
- voice command control
- voice note control
- camera capture control
- AI status chip
- cart / order ticket
- payment panel
- checkout / print action

## Apa Yang Boleh Berbeda

- warna
- spacing
- density
- label domain
- urutan panel
- icon style
- tombol cepat yang paling sering dipakai

## Apa Yang Tidak Boleh Berbeda

- struktur state transaksi
- cara input item
- cara checkout
- cara print
- cara sync
- cara error handling
- cara voice/vision diproses

## Peta Theme

### Retail

- Fokus: scan cepat, cart padat, checkout singkat
- Istilah: produk, SKU, stok, promo, harga
- Aksi utama: tambah item, diskon, bayar, cetak

### F&B

- Fokus: menu, order ticket, dapur, split bill
- Istilah: meja, modifier, kitchen, note
- Aksi utama: order, kirim dapur, bayar, print

### Bengkel

- Fokus: kendaraan, work order, parts, jasa, mekanik
- Istilah: plat, kilometer, inspeksi, estimasi selesai
- Aksi utama: tambah jasa, tambah sparepart, selesaikan WO

## Pola Theme Selection

Theme dipilih saat:

1. setup awal tenant
2. login outlet
3. perubahan mode admin

Contoh keputusan:

- `business_type = retail` -> pakai retail theme pack
- `business_type = fnb` -> pakai F&B theme pack
- `business_type = bengkel` -> pakai bengkel theme pack

## Struktur Konfigurasi

Contoh bentuk konfigurasi tema:

```json
{
  "business_type": "retail",
  "layout": "core-landscape",
  "density": "compact",
  "accent": "green",
  "features": {
    "voice": true,
    "voice_note": true,
    "camera_capture": true
  }
}
```

## Struktur Folder Yang Disarankan

```text
src/
  app/
  shells/
  themes/
    retail/
    fnb/
    bengkel/
  layouts/
    core/
    minimal/
    premium/
  modules/
    retail/
    fnb/
    bengkel/
  adapters/
    sajen/
    mcp/
  stores/
  components/
```

## Alur Render

1. POS membaca tenant context.
2. POS menentukan business type.
3. Theme registry memilih pack yang cocok.
4. Shell render slot yang sama.
5. Layout preset menentukan landscape atau portrait.
6. Token tema menentukan warna, spacing, dan emphasis.

## Aturan Implementasi

- Jangan buat tiga aplikasi UI terpisah.
- Jangan hardcode komponen per vertikal di luar theme registry.
- Jangan pindahkan logika transaksi ke theme layer.
- Jangan jadikan portrait sebagai codebase berbeda.

## Rekomendasi Praktis

Urutan pengerjaan paling aman:

1. Bangun `Core Shell`.
2. Bangun `Theme Registry`.
3. Implement `Retail Core`.
4. Turunkan ke `F&B` dan `Bengkel`.
5. Tambahkan `Minimal` dan `Premium`.
6. Tambahkan `Portrait` reflow.

## Output Akhir Yang Diharapkan

- satu codebase
- tiga theme usaha
- beberapa density preset
- portrait dan landscape dari komponen yang sama
- UI/UX tetap seragam

## Dokumen Eksekusi

Rujukan kerja saat mulai coding:

- [bizeto_pos_coding_contract.md](/Users/user/Kerjaan/jualan/docs/bizeto_pos_coding_contract.md)
