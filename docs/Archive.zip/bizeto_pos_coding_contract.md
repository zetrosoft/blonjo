# Bizeto POS Coding Contract

Dokumen ini dibuat agar proses coding Bizeto POS bisa berjalan tanpa berhenti untuk konfirmasi berulang.

Prinsip utamanya:

- jika keputusan tidak berisiko tinggi, pakai default di dokumen ini dan lanjut coding
- jika keputusan memengaruhi arsitektur inti, simpan sebagai catatan terpisah, bukan blocker
- targetnya adalah implementasi yang konsisten, rapi, dan minim bug

## Tujuan Implementasi

1. Menjadikan semua UI/UX sebagai tema dari satu codebase.
2. Menjaga visual layout tetap setia ke referensi gambar yang sudah dibuat.
3. Memastikan code mengikuti arsitektur yang sudah dirancang.
4. Menyiapkan fondasi yang mudah diuji, mudah dirawat, dan aman untuk ekspansi.

## Target Codebase

- Gunakan folder `blonjo/` sebagai workspace implementasi frontend.
- Anggap `blonjo/` sebagai single frontend app yang akan dipakai untuk Bizeto POS.
- Jangan pecah menjadi proyek terpisah untuk retail, F&B, atau bengkel.

## Baseline Tech Stack

Stack yang dipakai adalah stack modern yang sudah ada di workspace dan cocok untuk implementasi stabil:

- React
- Vite
- TypeScript
- Zustand
- React Router
- Tailwind CSS
- shadcn/ui
- Radix UI
- Axios
- Sonner
- next-themes
- lucide-react
- html5-qrcode

Untuk integrasi hardware dan adaptasi desktop/mobile, gunakan wrapper yang sesuai fase deployment:

- Tauri untuk desktop
- Capacitor untuk Android tablet

## Stack Policy

- Pakai versi stabil terbaru yang kompatibel dengan workspace saat coding dimulai.
- Pin versi lewat lockfile setelah instalasi agar build repeatable.
- Jangan upgrade major dependency tanpa alasan yang jelas.
- Jika library sudah ada dan stabil, pertahankan kecuali ada conflict arsitektur.

## Struktur Implementasi Default

Gunakan struktur berikut sebagai dasar:

```text
src/
  app/
  shells/
  themes/
    retail/
    fnb/
    bengkel/
  layouts/
    core/
    minimal/
    premium/
  modules/
    retail/
    fnb/
    bengkel/
  adapters/
    sajen/
    mcp/
  stores/
  components/
  hooks/
  utils/
```

## Aturan Coding

1. Satu shell, banyak theme.
2. Semua layout mengikuti slot yang sama.
3. Theme tidak boleh memegang logika transaksi inti.
4. State transaksi harus tetap domain-agnostic.
5. UI harus dibangun dari komponen kecil yang jelas tanggung jawabnya.
6. Hindari duplicating logic antar theme.
7. Gunakan naming yang konsisten dan mudah dibaca.

## Prioritas Fidelity UI

Urutan prioritas visual untuk implementasi:

1. struktur layout
2. hierarchy panel
3. spacing dan density
4. warna tema
5. iconography
6. motion dan micro-interaction

Tujuan utamanya adalah:

- layout terlihat sama dengan referensi gambar
- alur kerja kasir tetap cepat
- tema tetap bisa diganti tanpa merombak komponen

## Kontrak Tampilan

Semua tampilan harus mengikuti referensi visual yang sudah dibuat di `docs/`:

- retail core landscape
- retail core portrait
- retail minimal
- retail premium luxury
- bengkel core landscape
- bengkel core portrait
- bengkel minimal
- F&B core landscape
- F&B core portrait
- F&B minimal
- F&B premium luxury

Jika ada detail kecil yang belum tertulis, pakai referensi gambar sebagai sumber utama.

## Kontrak Flow

- Business type dipilih dari setup atau login outlet.
- Theme registry menentukan tema aktif.
- Layout preset menentukan density dan orientasi.
- Input dock harus memuat voice, voice note, dan camera capture.
- Voice, voice note, dan capture image bisa aktif bersamaan.
- ERPNext integration tetap terpisah dan tidak mengubah shell POS.

## Default Keputusan Saat Dokumen Belum Lengkap

Kalau ada detail yang belum tertulis, pakai default berikut:

- pilih struktur paling sederhana yang tetap scalable
- pilih komponen reusable
- pilih data flow yang eksplisit
- pilih naming yang domain-driven
- pilih implementasi yang mudah diuji

## Kriteria Kualitas

- code mudah dibaca
- component boundary jelas
- state tidak bercampur dengan view
- error handling eksplisit
- loading state konsisten
- tidak ada hardcode yang mengunci tema tertentu

## Langkah Eksekusi Berikutnya

1. Bangun AppShell dan Theme Registry.
2. Implementasikan Retail Core sebagai baseline.
3. Turunkan ke F&B dan Bengkel.
4. Tambahkan portrait reflow dan preset minimal/premium.
5. Baru lanjut ke integrasi hardware dan voice/vision.

## Catatan Penting

Dokumen ini dibuat untuk mengurangi kebutuhan konfirmasi selama implementasi.
Jika ada ketidakjelasan minor, lanjutkan dengan asumsi paling aman dan catat di changelog.

