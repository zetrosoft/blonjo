# Bizeto POS Todo
*(Frontend-only POS: data inti dari Sajen, AI/OCR/voice via MCP bila diperlukan)*

Dokumen ini menjadi backlog implementasi untuk Bizeto-POS sebagai **single frontend codebase** yang:
- mengambil master data, transaksi, stok, harga, auth, dan jurnal dari **Sajen**,
- memakai **MCP server** hanya untuk fitur AI seperti voice, OCR, dan smart text parsing,
- berjalan di **web**, lalu dipaketkan ke **desktop** dan **Android**, dengan **macOS next phase**.

## Prinsip Arsitektur

1. POS tidak memiliki backend sendiri.
2. Seluruh data inti tetap berada di Sajen.
3. MCP hanya dipakai untuk enhancement, bukan dependency transaksi inti.
4. Core POS harus tetap bisa dipakai saat AI/MCP tidak aktif.
5. Satu codebase frontend harus cukup untuk web, desktop, Android, dan macOS fase berikutnya.
6. Satu codebase harus bisa menampung beberapa theme usaha tanpa memecah flow inti.

## Dokumen Dasar

- Rancangan theme system ada di [bizeto_pos_theme_system.md](/Users/user/Kerjaan/jualan/docs/bizeto_pos_theme_system.md).
- Kontrak eksekusi coding ada di [bizeto_pos_coding_contract.md](/Users/user/Kerjaan/jualan/docs/bizeto_pos_coding_contract.md).
- Rancangan integrasi ERPNext plug-and-play ada di [bizeto_pos_erpnext_integration.md](/Users/user/Kerjaan/jualan/docs/bizeto_pos_erpnext_integration.md).

## Todo Prioritas

### Fase 0 - Fondasi Arsitektur dan Theme System

- [ ] Buat `AppShell` dasar yang menjadi parent untuk semua mode POS.
- [ ] Definisikan slot wajib: `HeaderStatus`, `BusinessSwitcher`, `InputDock`, `CandidateStrip`, `WorkSurface`, `PaymentSummary`, `ActionFooter`, dan `OverlayDrawer`.
- [ ] Bangun `Theme Registry` untuk memilih `retail`, `fnb`, atau `bengkel`.
- [ ] Bangun `Layout Preset` untuk `core`, `minimal`, `premium`, `landscape`, dan `portrait`.
- [ ] Definisikan design tokens bersama untuk warna, spacing, density, radius, shadow, dan icon emphasis.
- [ ] Buat mapping konfigurasi theme dari `business_type` dan `layout_mode`.
- [ ] Pastikan semua mode memakai state flow yang sama, hanya tema dan density yang berubah.

### Fase 1 - Fondasi Frontend POS

- [ ] Tetapkan route utama POS dan layout shell aplikasi.
- [ ] Buat auth flow ke Sajen langsung untuk login kasir, admin, dan manager.
- [ ] Siapkan store global frontend untuk session, tenant context, katalog, keranjang, dan sync queue.
- [ ] Buat API client tunggal ke Sajen untuk master data, transaksi, dan reporting.
- [ ] Tambahkan indikator status koneksi Sajen dan status MCP di header POS.
- [ ] Tambahkan pemilih business type saat setup awal atau login outlet.

### Fase 2 - Master Data dan Transaksi Inti

- [ ] Sinkronkan catalog produk dari Sajen ke cache lokal frontend.
- [ ] Ambil harga tenant, stok tenant, customer, supplier, dan staf dari Sajen.
- [ ] Implementasi keranjang transaksi dengan edit qty, diskon, dan catatan manual.
- [ ] Implementasi checkout cash, QRIS statis, QRIS dinamis, dan transfer manual.
- [ ] Finalisasi transaksi ke Sajen termasuk nomor referensi, jurnal, dan inventory log.
- [ ] Tampilkan receipt preview untuk thermal 58mm dan 80mm.
- [ ] Buat komponen transaksi generik yang bisa dipakai retail, F&B, dan bengkel.

### Fase 3 - AI / MCP Enhancement

- [ ] Hubungkan voice command ke MCP untuk intent operasional seperti `buat nota`, `print nota`, `bayar`, `cek harga`, dan `cek stok`.
- [ ] Hubungkan voice input ke MCP untuk speech-to-text dan entity extraction item.
- [ ] Implementasi voice note transcription yang langsung mengisi input nama item.
- [ ] Tambahkan handling ambiguitas kandidat item dan shortcut suara seperti `pilih baris ke 2`.
- [ ] Tambahkan parsing quantity dari ucapan agar qty langsung masuk ke item terpilih.
- [ ] Hubungkan capture image / camera vision ke MCP untuk foto produk, nota, atau area kerja.
- [ ] Hubungkan OCR kamera ke MCP untuk membaca produk atau nota.
- [ ] Hubungkan smart text input ke MCP untuk parsing item, qty, plate, dan pihak terkait.
- [ ] Terapkan fuzzy match ke catalog lokal setelah hasil MCP diterima.
- [ ] Tambahkan popup lookup untuk cek harga dan cek stok saat input hanya cocok sebagian.
- [ ] Tambahkan fallback manual quick add jika item tidak cocok.
- [ ] Satukan voice command, voice note, dan capture image dalam satu feature dock yang tetap bisa aktif bersamaan.
- [ ] Buat mekanisme candidate strip yang bisa dipilih dengan klik maupun perintah suara.

### Fase 4 - Offline-First

- [ ] Simpan draft transaksi lokal saat koneksi terputus.
- [ ] Buat queue sinkronisasi untuk transaksi `PENDING_SYNC`.
- [ ] Pastikan core flow barcode, manual input, checkout, dan print tetap jalan saat offline.
- [ ] Tambahkan retry sync saat koneksi Sajen kembali tersedia.

### Fase 5 - Hardware dan Device Support

- [ ] Integrasi barcode scanner.
- [ ] Integrasi thermal printer 58mm dan 80mm.
- [ ] Integrasi kamera untuk OCR, capture image, dan live preview vision.
- [ ] Integrasi mic untuk voice command dan voice note.
- [ ] Siapkan mode layar untuk desktop kasir, tablet Android, dan browser web.

### Fase 6 - Packaging Multi-Device

- [ ] Siapkan build web sebagai base distribution.
- [ ] Siapkan wrapper desktop untuk Windows dan macOS.
- [ ] Siapkan wrapper Android untuk tablet kasir.
- [ ] Dokumentasikan perbedaan capability tiap platform.
- [ ] Pastikan macOS masuk phase berikutnya tanpa mengubah core frontend.
- [ ] Pastikan theme retail, F&B, dan bengkel bisa dipilih saat build maupun runtime.

## Relasi Data Yang Harus Dipakai POS

- `tenants` untuk identitas toko dan konfigurasi cabang.
- `users` dan `roles` untuk akses kasir, manager, dan admin.
- `products`, `product_categories`, dan `uoms` untuk master katalog.
- `tenant_inventories` untuk stok dan HPP per tenant.
- `tenant_product_prices` untuk harga jual tenant.
- `tenant_pricing_rules` untuk aturan diskon, bundle, dan formula.
- `contacts` untuk customer, supplier, dan staf/mekanik.
- `transactions` untuk header transaksi POS.
- `journal_entries` untuk jurnal yang dibuat di Sajen.
- `inventory_logs` untuk pergerakan stok.
- `journal_mappings` dan `journal_mapping_lines` untuk auto-jurnal.
- `business_theme_configs` untuk pilihan theme POS per tenant atau outlet.
- `device_profiles` untuk mode desktop, tablet, dan mobile.

## Deliverable Minimum

1. POS bisa login ke Sajen.
2. POS bisa load catalog dan harga tenant.
3. POS bisa membuat transaksi normal tanpa AI.
4. POS bisa memanggil MCP saat voice/OCR/smart text dipakai.
5. POS bisa menjalankan voice command, voice note, dan capture image sesuai mode operasional.
6. POS bisa berjalan di web, desktop, dan Android dari basis frontend yang sama.
7. POS bisa memilih theme retail, F&B, atau bengkel dari shell yang sama.

## Intent Utama Operasional

### Command Intent

- `buat nota`
- `print nota`
- `bayar 150 ribu`
- `bayar via QRIS`
- `cek harga oli mpx2`
- `cek stok ban fdr`

### Lookup Intent

- Saat nama barang jelas, tampilkan popup detail produk.
- Saat nama barang ambigu, tampilkan list kandidat dan harga / stok yang relevan.
- Lookup mengikuti pricing rule aktif tenant.

### Transaction Intent

- Voice note langsung mengisi field nama item.
- Jika voice note mengandung qty, qty langsung diisi.
- Jika konteksnya mode nota, item langsung masuk ke cart aktif.
- Capture image dapat dipakai untuk menambahkan item ke nota atau sebagai lampiran transaksi.
