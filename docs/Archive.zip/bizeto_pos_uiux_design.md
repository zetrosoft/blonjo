# Bizeto POS UI/UX Design
*(Frontend-only POS design system untuk retail, bengkel, dan F&B)*

Dokumen ini merangkum rancangan UI/UX Bizeto POS untuk tiga vertikal bisnis utama:
- Retail supermarket / minimarket
- Bengkel Auto Service
- F&B / cafe / restoran

Seluruh desain dibuat untuk **tablet landscape** sebagai target utama, tetapi tetap bisa diturunkan ke desktop dan mobile tanpa mengubah fondasi frontend.

## Prinsip Utama

1. POS adalah frontend-only.
2. Data inti tetap di Sajen.
3. AI/OCR/voice hanya lewat MCP bila dibutuhkan.
4. Core POS harus tetap bisa dipakai tanpa AI.
5. Desain harus cepat, jelas, dan mudah dipakai kasir dalam kondisi sibuk.

## Tech Stack Frontend

### Core Stack

- **React** sebagai UI framework utama.
- **Vite** sebagai build tool dan dev server.
- **TypeScript** untuk tipe data dan kontrak UI yang lebih aman.
- **Zustand** untuk state global seperti session, cart, katalog, dan sync queue.
- **React Router** untuk navigasi halaman POS.
- **Tailwind CSS** untuk styling cepat dan konsisten.
- **shadcn/ui + Radix UI** untuk komponen dasar yang solid dan aksesibel.
- **Axios** untuk komunikasi ke Sajen.
- **sonner** untuk notifikasi ringan.
- **next-themes** untuk switch tema jika diperlukan.
- **html5-qrcode** untuk alur barcode / scan kamera.
- **lucide-react** untuk icon set ringan dan konsisten.

### Packaging Target

- **Web** sebagai basis utama.
- **Tauri** untuk desktop.
- **Capacitor** untuk Android tablet.
- **macOS** masuk phase berikutnya tanpa mengubah core UI.

## Theme System

Semua varian UI/UX Bizeto POS dibangun dari **satu komponen dasar** yang sama. Perbedaan retail, F&B, dan bengkel hanya berupa tema bisnis dan densitas layout.

### Dasar Implementasi Coding

Baseline coding yang paling aman adalah **Core Shell** dengan referensi visual utama dari **Retail Core Landscape**.

Alasan pilihannya:
- paling dekat ke pola POS generik
- paling mudah dipakai sebagai fondasi component library
- mudah direflow ke portrait, minimal, dan premium tanpa cabang code berbeda

### Yang Berubah Antar Tema

- warna dan tokens
- spacing dan density
- urutan panel
- label dan istilah domain
- shortcut operasional

### Yang Tidak Berubah

- struktur app shell
- input dock voice dan vision
- cart / order ticket
- payment summary
- aksi checkout dan print

### Mode Tema

- `retail` untuk supermarket, minimarket, toko kelontong
- `fnb` untuk cafe, restoran, dan outlet makanan
- `bengkel` untuk work order service center

### Arah Pengembangan

Model visual di dokumen ini menjadi referensi desain, sedangkan implementasinya harus tetap memakai satu codebase dan satu state flow.

## Arsitektur UI

Struktur umum Bizeto POS dibuat konsisten di semua mode:

1. Header status
   - Tenant / outlet
   - Status Sajen
   - Status MCP
   - Status offline / online
2. Area input
   - barcode
   - search
   - voice
   - voice note
   - capture image
   - OCR
3. Area cart / work order / order ticket
4. Area pembayaran
5. Area aksi final
   - checkout
   - print
   - sync

### Feature Dock Voice & Vision

Selain struktur umum di atas, layout kasir perlu punya dock aksi yang tampak jelas untuk 3 fitur penting:

- `Mic Command` untuk perintah suara operasional
- `Mic Note` untuk voice note item atau catatan transaksi
- `Camera Capture` untuk foto produk, nota, atau area kerja
- `AI status chip` untuk menunjukkan apakah MCP online
- `Candidate popup` untuk memilih item saat transkrip ambigu

Dock ini sebaiknya ditempatkan dekat area input utama supaya kasir tidak perlu berpindah fokus terlalu jauh.

Tiga kontrol utama ini harus didesain sebagai fitur yang dapat aktif bersamaan:

- `Mic Command` tetap bisa dipakai saat `Mic Note` aktif.
- `Camera Capture` tetap bisa dipakai saat salah satu mic aktif.
- Status aktivitas masing-masing kontrol harus terlihat terpisah agar kasir tahu mana yang sedang merekam, mana yang standby, dan mana yang siap dipakai.

## Mode Desain Retail

### Retail Core Landscape

File: [bizeto-pos-retail-core-landscape.png](/Users/user/Kerjaan/jualan/docs/bizeto-pos-retail-core-landscape.png)

Pasangan portrait: [bizeto-pos-retail-core-portrait.png](/Users/user/Kerjaan/jualan/docs/bizeto-pos-retail-core-portrait.png)

Retail core landscape adalah layout yang paling seimbang untuk kasir supermarket.

#### Ciri Visual
- Warna utama putih, hijau, biru, dan abu netral.
- Layout padat tetapi masih lega.
- Fokus pada barcode scan, product cart, promo, dan total bayar.

#### Komponen Utama
- Top barcode scan bar.
- Search produk dengan focus state.
- Cart table dengan SKU, qty, harga, promo.
- Payment summary panel.
- Checkout button yang tegas.

#### Kegunaan
- Cocok untuk minimarket, supermarket kecil, dan toko retail yang butuh kecepatan.
- Ini adalah baseline paling aman untuk implementasi cepat.

### Retail Minimal

File: [bizeto-pos-retail-minimal.png](/Users/user/Kerjaan/jualan/docs/bizeto-pos-retail-minimal.png)

Retail minimal dibuat untuk implementasi yang ringan dan sangat mudah dibaca.

#### Ciri Visual
- Banyak whitespace.
- Panel sederhana, tipografi jelas.
- Aksen warna tipis supaya kasir tidak terdistraksi.

#### Komponen Utama
- Scan field yang dominan.
- Cart list ringkas.
- Promo label sederhana.
- Summary pembayaran minimal.

#### Kegunaan
- Cocok untuk kasir dengan workflow sangat cepat.
- Bagus untuk tahap awal development dan QA.

### Retail Premium Luxury

File: [bizeto-pos-retail-premium-luxury.png](/Users/user/Kerjaan/jualan/docs/bizeto-pos-retail-premium-luxury.png)

Retail premium luxury adalah versi visual yang lebih eksklusif.

#### Ciri Visual
- Emerald, gold, black, ivory.
- Card surfaces lebih halus dan elegan.
- Typography terasa premium.

#### Komponen Utama
- Barcode scan strip tetap ada.
- Cart dense tetapi tampil lebih mewah.
- Promo cards dan price cut styling lebih polished.
- Checkout area lebih ekspresif.

#### Kegunaan
- Cocok untuk retail premium atau brand yang ingin kesan eksklusif.
- Tetap fungsional untuk kasir, bukan sekadar estetika.

## Mode Desain Bengkel

### Bengkel Core Landscape

File: [bizeto-pos-bengkel-core-landscape.png](/Users/user/Kerjaan/jualan/docs/bizeto-pos-bengkel-core-landscape.png)

Pasangan portrait: [bizeto-pos-bengkel-core-portrait.png](/Users/user/Kerjaan/jualan/docs/bizeto-pos-bengkel-core-portrait.png)

Versi ini paling cocok untuk alur work order bengkel yang lengkap.

#### Ciri Visual
- Slate, light gray, muted blue, aksen orange.
- Fokus pada data kendaraan dan status service.
- Layout terasa operasional.

#### Komponen Utama
- Vehicle header card.
- Customer info.
- Plate number dan mileage.
- Mechanic assignment.
- Work order list untuk parts dan labor.
- Warranty / next service estimate panel.

#### Kegunaan
- Cocok untuk bengkel motor, bengkel mobil, dan service center.
- Bagus untuk front desk yang perlu informasi lengkap dalam satu layar.

### Bengkel Minimal

File: [bizeto-pos-bengkel-minimal.png](/Users/user/Kerjaan/jualan/docs/bizeto-pos-bengkel-minimal.png)

Bengkel minimal fokus pada keterbacaan dan kejelasan data.

#### Ciri Visual
- Warna lebih tenang.
- Panel lebih bersih.
- Tidak banyak dekorasi.

#### Komponen Utama
- Vehicle info header.
- Compact work order list.
- Status chips service.
- Notes area.
- Payment summary sederhana.

#### Kegunaan
- Cocok untuk tablet kasir yang dipakai di meja service.
- Mudah diimplementasikan dan cepat dipelajari staf baru.

## Mode Desain F&B

### F&B Core Landscape

File: [bizeto-pos-fnb-core-landscape.png](/Users/user/Kerjaan/jualan/docs/bizeto-pos-fnb-core-landscape.png)

Pasangan portrait: [bizeto-pos-fnb-core-portrait.png](/Users/user/Kerjaan/jualan/docs/bizeto-pos-fnb-core-portrait.png)

F&B core landscape dirancang untuk transaksi makanan dan minuman yang cepat tetapi tetap rapi.

#### Ciri Visual
- Terracotta, amber, cream, dark mocha.
- Layout hangat dan friendly.
- Order ticket mudah dibaca.

#### Komponen Utama
- Menu category rail.
- Order ticket pusat dengan table number.
- Modifier chips.
- Kitchen send status.
- Payment summary panel.

#### Kegunaan
- Cocok untuk cafe, restoran, dan outlet makanan cepat saji.
- Kompromi yang baik antara estetika dan kecepatan operasional.

### F&B Minimal

File: [bizeto-pos-fnb-minimal.png](/Users/user/Kerjaan/jualan/docs/bizeto-pos-fnb-minimal.png)

F&B minimal adalah versi yang lebih ringan dan mudah diimplementasikan.

#### Ciri Visual
- Warna lembut.
- Elemen tidak ramai.
- Struktur order ticket sederhana.

#### Komponen Utama
- Menu list.
- Ticket order ringkas.
- Modifier chips kecil.
- Summary pembayaran sederhana.

#### Kegunaan
- Cocok untuk tahap MVP.
- Bagus untuk outlet kecil yang butuh tampilan bersih.

### F&B Premium Luxury

File: [bizeto-pos-fnb-premium-luxury.png](/Users/user/Kerjaan/jualan/docs/bizeto-pos-fnb-premium-luxury.png)

F&B premium luxury memberi kesan restoran kelas atas.

#### Ciri Visual
- Burgundy, gold, charcoal, warm cream.
- Card dan spacing terasa refined.
- UI lebih elegan tanpa mengorbankan fungsi.

#### Komponen Utama
- Category rail premium.
- Ticket order dengan hierarchy visual yang kuat.
- Kitchen status yang jelas.
- Payment area yang menonjol.

#### Kegunaan
- Cocok untuk restoran premium, cafe boutique, dan brand hospitality yang ingin tampil eksklusif.

## Alur Proses POS

### 1. Login

- Kasir login ke Sajen melalui frontend.
- Frontend menerima token, tenant context, dan role user.
- UI menyesuaikan menu berdasarkan hak akses.

### 2. Load Master Data

- POS menarik catalog produk dari Sajen.
- Harga tenant, stok tenant, customer, supplier, dan staf ikut dimuat.
- Data penting disimpan di cache lokal agar tetap bisa dipakai offline.

### 3. Input Transaksi

Tiga jalur input utama:

- Barcode scanner
- Manual search / quick add
- Voice command
- Voice note transcription
- Capture image / camera vision
- OCR / smart text via MCP

### 4. Edit Cart / Work Order / Order Ticket

- Kasir mengubah qty, diskon, dan catatan manual.
- Untuk F&B, modifier dan kitchen note ditambahkan.
- Untuk voice note, hasil ucapan langsung mengisi nama item; jika ambigu, tampilkan list kandidat dan dukung perintah seperti `pilih baris ke 2`.
- Untuk capture image, hasil foto dapat dipakai untuk analisis item atau menjadi lampiran transaksi.
- Untuk bengkel, data kendaraan dan mekanik ikut tercatat.

### 5. Checkout

- Pilih metode bayar.
- Cash, QRIS statis, QRIS dinamis, atau transfer manual.
- Hitung total, pajak, service charge, dan kembalian.

### 6. Finalisasi

- Transaksi dikirim ke Sajen.
- Sajen mencatat transaksi, jurnal, dan inventory log.
- Receipt preview dipakai untuk print thermal.

### 7. Sync dan Offline Recovery

- Jika offline, transaksi masuk queue lokal.
- Saat koneksi kembali, queue disinkronkan ke Sajen.
- Core flow tetap aktif walau AI/MCP sedang nonaktif.

## Aturan Desain Per Mode

### Retail

- Prioritas kecepatan scan.
- Cart padat dan jelas.
- Promo dan harga harus sangat terlihat.

### Bengkel

- Prioritas data kendaraan dan mekanik.
- Status service harus eksplisit.
- Work order harus mudah dipahami.

### F&B

- Prioritas order ticket dan kitchen flow.
- Modifier harus cepat diakses.
- Payment summary harus mudah dibaca oleh kasir.

## Rekomendasi Implementasi

1. Mulai dari versi minimal tiap mode untuk baseline development.
2. Tambahkan core landscape sebagai versi produksi utama.
3. Tambahkan premium luxury untuk outlet dengan kebutuhan brand tinggi.
4. Pastikan semua mode memakai struktur state dan flow yang sama.
5. Simpan asset gambar ini sebagai referensi visual untuk implementasi frontend.

## Referensi Gambar

- [Retail Core Landscape](/Users/user/Kerjaan/jualan/docs/bizeto-pos-retail-core-landscape.png)
- [Retail Core Portrait](/Users/user/Kerjaan/jualan/docs/bizeto-pos-retail-core-portrait.png)
- [Retail Minimal](/Users/user/Kerjaan/jualan/docs/bizeto-pos-retail-minimal.png)
- [Retail Premium Luxury](/Users/user/Kerjaan/jualan/docs/bizeto-pos-retail-premium-luxury.png)
- [Bengkel Core Landscape](/Users/user/Kerjaan/jualan/docs/bizeto-pos-bengkel-core-landscape.png)
- [Bengkel Core Portrait](/Users/user/Kerjaan/jualan/docs/bizeto-pos-bengkel-core-portrait.png)
- [Bengkel Minimal](/Users/user/Kerjaan/jualan/docs/bizeto-pos-bengkel-minimal.png)
- [F&B Core Landscape](/Users/user/Kerjaan/jualan/docs/bizeto-pos-fnb-core-landscape.png)
- [F&B Core Portrait](/Users/user/Kerjaan/jualan/docs/bizeto-pos-fnb-core-portrait.png)
- [F&B Minimal](/Users/user/Kerjaan/jualan/docs/bizeto-pos-fnb-minimal.png)
- [F&B Premium Luxury](/Users/user/Kerjaan/jualan/docs/bizeto-pos-fnb-premium-luxury.png)
